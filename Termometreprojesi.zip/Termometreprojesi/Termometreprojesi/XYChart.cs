﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Termometreprojesi
{
    class XYChart
    {
        internal int getWidth()
        {
            throw new NotImplementedException();
        }

        internal int getHeight()
        {
            throw new NotImplementedException();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Termometreprojesi
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        OleDbConnection bag = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=sicaklik.accdb");
        DataTable tablo = new DataTable();
        OleDbDataAdapter adtr = new OleDbDataAdapter();
        OleDbCommand kmt =new OleDbCommand();

        void listele()
        { 
            tablo.Clear();
            bag.Open();
            OleDbDataAdapter adtr = new OleDbDataAdapter("select * From sicaklikd", bag);
            adtr.Fill(tablo);
            dataGridView1.DataSource = tablo;
            adtr.Dispose();
            bag.Close();
        }
 
        private void Form1_Load(object sender, EventArgs e)
        {
            listele();
            dataGridView1.Columns[0].HeaderText = "Sicaklikbir";
            dataGridView1.Columns[1].HeaderText = "Sicaklikiki";
            dataGridView1.Columns[2].HeaderText = "Sicaklikuc";
        } 
 
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                bag.Open(); 
                kmt.Connection = bag; 
                kmt.CommandText = "INSERT INTO sicaklikd(Sicaklikbir,Sicaklikiki,Sicaklikuc) VALUES ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')"; 
                kmt.ExecuteNonQuery();
                kmt.Dispose(); 
                bag.Close(); 
                listele(); 
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception hataturu)
            {
                MessageBox.Show("Hata :" + hataturu.Message);
            }
            finally
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
 
    }
 
} 


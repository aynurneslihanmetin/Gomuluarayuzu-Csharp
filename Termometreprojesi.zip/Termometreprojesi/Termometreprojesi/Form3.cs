﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports; 
using System.Data.OleDb;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;
using System.Diagnostics;
using rtChart;
using ZedGraph;

namespace Termometreprojesi
{
    public partial class Form3 : Form
    {

        public static System.IO.Ports.SerialPort serialport1;
        private delegate void LineReceivedEvents(string line);

        string[] portlar = SerialPort.GetPortNames();
        GraphPane myPane;
        public Form3()
        {
            InitializeComponent();
            modifyProgressBar.SendState(verticalProgressBar1, 2);
            myPane = zed.GraphPane;


        }
        int TickStart, intMode = 1;
        int h = 6000000;

        private void Form3_Load(object sender, EventArgs e)
        {
       
            GraphPane myPane = zed.GraphPane;
            myPane.Title.Text = "Sıcaklık Grafiği";
            myPane.XAxis.Title.Text = "Time";
            myPane.XAxis.Title.Text = "Güncel Değer";
            RollingPointPairList list = new RollingPointPairList(h);
            LineItem curve1 = myPane.AddCurve("Güncel Sıcaklık",list, Color.Red, SymbolType.None);
            myPane.XAxis.Scale.Min = 0;
            myPane.XAxis.Scale.Max = 100;
            myPane.XAxis.Scale.MinorStep = 1;
            myPane.XAxis.Scale.MajorStep = 5;
            myPane.YAxis.Scale.Min = 0;
            myPane.YAxis.Scale.Max = 40;
            myPane.YAxis.Scale.MinorStep = 1.00;
            myPane.YAxis.Scale.MajorStep = 2.00;
   
            zed.AxisChange();
            zed.Invalidate();
            TickStart = Environment.TickCount;
         //  zed.IsShowPointValues = true;
            foreach (string port in portlar)
            {
                comboBox1.Items.Add(port);
                comboBox1.SelectedIndex = 0;
            }
            comboBox2.Items.Add("4800");
            comboBox2.Items.Add("9600");
            comboBox2.Items.Add("115200");
            comboBox2.SelectedIndex = 1;

            label2.Text = "Baglantı kapalı";
        }
        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Close();
            }

        }
        int sayac = 1;
        int k = 4;
        int g = 586;
        int ps = 400;
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                string sonuc = serialPort1.ReadLine();
                label1.Text = sonuc + "";
                if (sonuc.Length >= 10)
                {
                    string[] pot = new string[3];
                    pot = sonuc.Split('*');
                    if (pot.Length != 3)
                    {
                        return;
                    }
                    label10.Text = pot[0];
                    if (k == 4)
                    {
                        label11.Text = pot[1];
                        label13.Text = pot[2];
                    }
                    string[] a = pot[0].Split('.');
                    string b = a[0] + "," + a[1];
                    float j;
                    float.TryParse(b, out j);

                    if (sayac == 1)
                        Draw(j);
                    else if (sayac == 2)
                    {

                    }
                    string[] cot = sonuc.Split('.');
                    label20.Text = cot[0];
                    int z;
                    int.TryParse(cot[0], out z);
                    verticalProgressBar1.Value = z;
                    




                    if (g < 1460)
                    {
                       
                        g += 1;
                    }
                    else
                    {
                        g = 1460;
                    }
                    /////////////////////////////////////////////////////////
                   
                    if (z <= 25)
                    {
                        ps =460;
                    }
                    else if (z == 26)
                    {
                        ps =440;
                    }
                    else if (z == 27)
                    {
                        ps =420;
                    }
                    else if (z == 28)
                    {
                        ps =400;
                    }
                    else if (z == 29)
                    {
                        ps = 380;
                    }
                    else if (z == 30)
                    {
                        ps = 360;
                    }
                    else if (z == 31)
                    {
                        ps = 340;
                    }
                    else if (z == 32)
                    {
                        ps = 320;
                    }
                    else if (z == 33)
                    {
                        ps = 300;
                    }
                    else if (z <= 34)
                    {
                        ps = 290; ;
                    }
                    else if (z == 35)
                    {
                        ps = 280;
                    }
                    else if (z == 36)
                    {
                        ps = 270;
                    }
                    else if (z == 37)
                    {
                        ps = 260;
                    }
                    else if (z == 38)
                    {
                        ps = 250;
                    }
                    else if (z == 39)
                    {
                        ps = 240;
                    }
                    else if (z == 40)
                    {
                        ps = 230;
                    }
                    else if (z == 41)
                    {
                        ps = 220;
                    }
                    else if (z == 42)
                    {
                        ps = 210;
                    }
                    else
                    {
                        ps = 220;
                    }
                    label18.Location = new Point(g, ps);
                }
                zed.IsShowPointValues = true;
             //   zed.IsShowCursorValues = true;
             //   System.Diagnostics.Debug.WriteLine(zed.IsShowCursorValues + "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
                verticalProgressBar1.Value = 89;
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("serialreadhatası");

            }
        }

  
        private void button1_Click(object sender, EventArgs e)
        {

            timer1.Start();
            if (serialPort1.IsOpen == false)
            {
                if (comboBox1.Text == "")
                    return;
                serialPort1.PortName = comboBox1.Text;
                serialPort1.BaudRate = Convert.ToInt16(comboBox2.Text);
                try
                {
                    serialPort1.Open();

                    label2.Text = "Baglantı Acık";
                }
                catch (Exception hata)
                {
                    MessageBox.Show("Hata :" + hata.Message);
                    MessageBox.Show("buton");
                }
            }
            else
            {
                label2.Text = "Baglantı Kuruldu";
            }
            TickStart = Environment.TickCount;
        }
        private void button2_Click(object sender, EventArgs e)
        {

            timer1.Stop();

            serialPort1.DiscardInBuffer();
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Close();
                label2.Text = "Baglantı Kapalı";
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = label10.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox2.Text = label10.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox3.Text = label10.Text;
        }


        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void button8_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.textBox1.Text = textBox1.Text;
            form.textBox2.Text = textBox2.Text;
            form.textBox3.Text = textBox3.Text;

            form.ShowDialog();
        }


        private void timer2_Tick(object sender, EventArgs e)
        {
            try
            {
                Random sayi = new Random();
                label10.Text = sayi.Next(20, 40).ToString();
                int t = Convert.ToInt32(label10.Text);
                verticalProgressBar1.Value = t;
                int r = 520;
                r-=t;
                if (g < 1510)
                {
                    g +=6;
                }
                else
                {
                    g = 1510;
                }
                label18.Location = new Point(g, r); 
            }
            catch (Exception exx)
            {
                MessageBox.Show(exx.Message);
                MessageBox.Show("randomhata");
                timer2.Stop();

            }
        }

        private void simülatörOlarakÇalıştırToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            timer2.Start();
            label11.Text = "25";
            label13.Text = "30";
            TickStart = Environment.TickCount;
        }
        private string ToString(Random sayi)
        {
            throw new NotImplementedException();
        }
        private void sicaklikDegerleriniKaydetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 i = new Form4();
            i.Show();
        }


        private void getPerformanceCounter()
        {
            throw new NotImplementedException();

        }

        private void maxmindegerleriguncellebutonu_Click(object sender, EventArgs e)
        {


            string x = textBox5.Text;
            string[] zot = new string[2];
            zot = x.Split('*');
            k = 5;
            if (k == 5)
            {
                label11.Text = zot[0];
                label13.Text = zot[1];
            }

            string r = textBox5.Text;
            serialPort1.Write(r);
            int f = Convert.ToInt32(zot[0]);
            int g = Convert.ToInt32(zot[1]);
            if (f >= g)
            {
               timer1.Stop();
               sayac = 2;
               zed.AxisChange();
               button3.Text = "DEVAM ET";
                MessageBox.Show("min max eşit olamaz");
            }
            textBox5.Text = "";
        }
        private void Draw(float setpoint)
        {
            float intsetpoint;
            intsetpoint = setpoint;
            if (zed.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curve = zed.GraphPane.CurveList[0] as LineItem;
            if (curve == null)
                return;
            IPointListEdit list = curve.Points as IPointListEdit;
            if (list == null)
                return;
            double time = (Environment.TickCount - TickStart) / 1000.0;
            list.Add(time, intsetpoint);
            Scale xScale = zed.GraphPane.XAxis.Scale;
            if (time > xScale.Max - xScale.MajorStep)
            {
                if (intMode == 1)
                {
                    xScale.Max = time + xScale.MajorStep;
                    xScale.Min = xScale.Max - 10.0;
                }


                else
                {
                    xScale.Max = time + xScale.MajorStep;
                    xScale.Min = 0;
                }
            }
            string t = time.ToString();

            label18.Text ="("+ t + " , " + label10.Text+")";
            label17.Text = t + " , " + label10.Text;
            zed.AxisChange();
            zed.Invalidate();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == "DUR")
            {
                timer1.Stop();
                sayac = 2;
                zed.AxisChange();
                button3.Text = "DEVAM ET";
            }
            else
            {
                timer1.Start();
                button3.Text = "DUR";
               // g = 688;
               // ps = 358;
                sayac = 1;
                GraphPane myPane = zed.GraphPane;
                myPane.Title.Text = "Sıcaklık Grafiği";
                myPane.XAxis.Title.Text = "Time";
                myPane.XAxis.Title.Text = "Güncel Değer";
                RollingPointPairList list = new RollingPointPairList(h);
                LineItem curve1 = myPane.AddCurve("", list, Color.Red, SymbolType.None);

                myPane.XAxis.Scale.Min = 0;
                myPane.XAxis.Scale.Max = 100;
                myPane.XAxis.Scale.MinorStep = 1.00;
                myPane.XAxis.Scale.MajorStep = 1.05;
                myPane.YAxis.Scale.Min = 0;
                myPane.YAxis.Scale.Max = 40;
                myPane.YAxis.Scale.MinorStep = 1.00;
                myPane.YAxis.Scale.MajorStep = 1.05;
                zed.AxisChange();
            }
        }
    }
}
